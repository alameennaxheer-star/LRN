# LRN App — Render starter

This is a minimal Node.js/Express starter service. It is **not** the full LRN application; replace or extend it with the actual app code and features.

## Run locally
1. Install Node.js.
2. In this folder, run `npm install`.
3. Run `npm start`.
4. Open http://localhost:10000

## Deploy on Render
Create a Render **Web Service** connected to this repository, then use:
- Build Command: `npm install`
- Start Command: `npm start`

Render provides the `PORT` environment variable automatically.

## Endpoints
- `/` — starter page
- `/health` — JSON health check
