const express = require("express");

const app = express();
const PORT = process.env.PORT || 10000;

app.get("/", (req, res) => {
  res.send(`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LRN App</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 720px; margin: 10vh auto; padding: 0 20px; line-height: 1.6; }
    main { border: 1px solid #ddd; border-radius: 16px; padding: 28px; }
    h1 { margin-top: 0; }
  </style>
</head>
<body>
  <main>
    <h1>LRN App</h1>
    <p>Your Node.js web service is running successfully on Render.</p>
    <p>This is a starter template. Add your actual LRN features here.</p>
  </main>
</body>
</html>`);
});

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`LRN app listening on port ${PORT}`);
});
